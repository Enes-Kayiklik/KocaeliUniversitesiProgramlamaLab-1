#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    int plaka;
    int komsuSayisi;
    char sehir[50];
    char bolge[50];
    struct node *next;
    struct node *prev;
    struct komsu *komsu;
};
struct komsu
{
    char sehir[50];
    struct node *ileri;
};

struct node *ilk=NULL, *son=NULL;
struct komsu *sonKomsu[100];

void KomsuEkle(char sehir[100],int sayi)
{
    struct komsu *yeni = (struct komsu*) malloc(sizeof(struct komsu));
    struct node *iter=ilk;
    for(int i=0; i<sayi; i++)
    {
        iter=iter->next;
    }
    struct komsu *komsuIter=iter->komsu;

    for(int i=0; sehir[i]!='\0'; i++)
    {
        yeni->sehir[i]=sehir[i];
    }
    if(komsuIter==NULL)
    {
        sonKomsu[sayi]=yeni;
        iter->komsu=yeni;
        sonKomsu[sayi]->ileri=NULL;
    }
    else
    {
        sonKomsu[sayi]->ileri=yeni;
        sonKomsu[sayi]=yeni;
        sonKomsu[sayi]->ileri=NULL;
    }
}

void SonaEkle(int plaka,char sehir[50],char bolge[50],int komsuSayisi)
{
    struct node *yeni = (struct node*) malloc(sizeof(struct node));

    yeni->plaka=plaka;
    yeni->komsuSayisi=komsuSayisi+1;

    for(int i=0; sehir[i]!='\0'; i++)
    {
        yeni->sehir[i]=sehir[i];
    }
    for(int i=0; bolge[i]!='\0'; i++)
    {
        yeni->bolge[i]=bolge[i];
    }
    if(ilk==NULL)
    {
        ilk=yeni;
        son=yeni;
        son->next=son;
        son->prev=ilk;
    }
    else
    {
        son->next=yeni;
        yeni->prev=son;
        yeni->next=ilk;
        ilk->prev=yeni;
        son=yeni;
    }
}
void dosyayaListele(int komsuSayisi[100])
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    fprintf(yazma,"\n\n\t\t\t\tTUM SEHIRLERIN LISTESI\n\n");
    struct node *liste=ilk;
    int k=0;
    int plaka[15];
    int tut;

    while(liste->next!=ilk)
    {
        struct komsu *komsuIter=liste->komsu;
        fprintf(yazma,"%d %s %s *%d*-> ",liste->plaka,liste->sehir,liste->bolge,liste->komsuSayisi);

        if(komsuIter!=NULL)
        {
            while(komsuIter->ileri!=NULL)
            {

                int plakaGecici=dosyaAramaYap(komsuIter->sehir);

                if(plakaGecici!=0)
                {
                    plaka[k]=plakaGecici;
                    k++;
                }
                komsuIter=komsuIter->ileri;

            }
            plaka[k]=dosyaAramaYap(komsuIter->sehir);
            for(int i=1; i<liste->komsuSayisi; i++)
            {
                for(int j=0; j<liste->komsuSayisi; j++)
                {
                    if(plaka[j]>plaka[j+1])
                    {
                        tut=plaka[j];
                        plaka[j]=plaka[j+1];
                        plaka[j+1]=tut;
                    }
                }
            }
            for(int i=0; i<liste->komsuSayisi+1; i++)
            {
                if(plaka[i]!=0)
                {
                    fprintf(yazma,"%d ",plaka[i]);
                }

            }
        }
        fprintf(yazma,"\n");
        liste=liste->next;
        k=0;
        for(int i=0; i<liste->komsuSayisi+1; i++)
            {
                plaka[i]=0;
            }
    }
    fprintf(yazma,"%d %s %s -> ",liste->plaka,liste->sehir,liste->bolge);
    struct komsu *komsuIter=liste->komsu;
    if(komsuIter!=NULL)
    {
        while(komsuIter->ileri!=NULL)
        {
            fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
            komsuIter=komsuIter->ileri;
        }
        fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
    }
}
void Listele(int komsuSayisi[100])
{

    struct node *liste=ilk;
    int j=0;

    while(liste->next!=ilk)
    {
        struct komsu *komsuIter=liste->komsu;
        printf("%d %s %s ",liste->plaka,liste->sehir,liste->bolge);

        if(komsuIter!=NULL)
        {
            while(komsuIter->ileri!=NULL)
            {
                aramaYap(komsuIter->sehir);
                komsuIter=komsuIter->ileri;
            }
            aramaYap(komsuIter->sehir);
        }
        printf("\n");
        liste=liste->next;
    }
    printf("%d %s %s ",liste->plaka,liste->sehir,liste->bolge);
    struct komsu *komsuIter=liste->komsu;
    if(komsuIter!=NULL)
    {
        while(komsuIter->ileri!=NULL)
        {
            aramaYap(komsuIter->sehir);
            komsuIter=komsuIter->ileri;
        }
        aramaYap(komsuIter->sehir);
    }
}
void plakaSil(int plaka)
{
    int sayac=0;
    int boolean=0;
    struct node *sil=ilk;
    while(sil!=NULL)
    {
        if(sil->plaka==plaka)
            break;
        else
        {
            sayac++;
            sil=sil->next;
        }
        if(sayac>500)
        {
            boolean=1;
            printf("\n\n\tBu plakada bir sehir bulunamadi");
            break;
        }
    }
    if(boolean==0)
    {
        if(sil!=NULL)
        {
            if(sil==ilk)
            {
                free(sil->komsu);
                sil->prev->next=sil->next;
                sil->next->prev=sil->prev;
                ilk=ilk->next;
            }
            else if(sil==son)
            {
                free(sil->komsu);
                sil->prev->next=sil->next;
                sil->next->prev=sil->prev;
                son=son->prev;
            }
            else
            {
                free(sil->komsu);
                sil->prev->next=sil->next;
                sil->next->prev=sil->prev;
            }
            free(sil);
        }
    }
}
void isimSil(char sehir[500])
{
    int sayac=0;
    int boolean=0;
    struct node *sil=ilk;
    while(sil!=NULL)
    {
        if(strcmp(sil->sehir,sehir)==0)
            break;
        else
        {
            sayac++;
            sil=sil->next;
        }
        if(sayac>500)
        {
            boolean=1;
            printf("\n\n\tBu isimde bir sehir bulunamadi");
            break;
        }
    }
    if(boolean==0)
    {
        if(sil!=NULL)
        {
            if(sil==ilk)
            {
                free(sil->komsu);
                sil->prev->next=sil->next;
                sil->next->prev=sil->prev;
                ilk=ilk->next;
            }
            else if(sil==son)
            {
                free(sil->komsu);
                sil->prev->next=sil->next;
                sil->next->prev=sil->prev;
                son=son->prev;
            }
            else
            {
                free(sil->komsu);
                sil->prev->next=sil->next;
                sil->next->prev=sil->prev;
            }
            for(int i=0; i<30; i++)
            {
                sil->sehir[i]=NULL;
            }
            free(sil);
        }
    }

}
/****************************/
/****************************/
/************MAIN************/
/****************************/
/****************************/
int main()
{
    system("color 2");
    FILE *yazma;
    yazma=fopen("cikti.txt","w+");
    int komsuSayisi=bagliListeOlustur();
    int secim;
    int plaka;

    while(secim!=0)
    {
        menuGoster();
        printf("\n\n\tYapacaginiz islem numarasini giriniz.");
        scanf("%d",&secim);

        switch(secim)
        {
        case 1:
            eklemeYap();
            break;
        case 2:
            komsuyaEklemeYap();
            break;
        case 3:
            sehirSilSecim();
            break;
        case 4:
            komsuSilSecim();
            break;
        case 5:
            bilgiGoruntuleSekmesi(komsuSayisi);
            break;
        case 0:
            dosyayaListele(komsuSayisi);
            break;
        }
    }
    fclose(yazma);

    return 0;
}
void komsuSilSecim()
{
    int secim;
    int plaka;
    char sehir[500];
    char silinecek[500];

    printf("\n\n\tSilinecek komsunun sehrini arama kriterini giriniz");
    printf("\n\n\t\t1-Plaka ile arama");
    printf("\n\t\t2-Isim ile arama");
    printf("\n\n\tSeciminizi yapiniz.");
    scanf("%d",&secim);

    switch(secim)
    {
    case 1:
        printf("\n\n\tSehrin plakasini giriniz.");
        scanf("%d",&plaka);
        printf("\n\n\tSilinecek komsunun ismini giriniz.");
        scanf("%s",&silinecek);
        plakaKomsuSil(plaka,silinecek);
        break;
    case 2:
        printf("\n\n\tSehrin ismini giriniz.");
        scanf("%s",&sehir);
        printf("\n\n\tSilinecek komsunun ismini giriniz.");
        scanf("%s",&silinecek);
        isimKomsuSil(sehir,silinecek);
        break;
    }
}
void sehirSilSecim()
{
    int secim;
    int plaka;
    char sehir[500];

    printf("\n\n\tSilinecek sehri arama kriterini giriniz");
    printf("\n\n\t\t1-Plaka ile arama");
    printf("\n\t\t2-Isim ile arama");
    printf("\n\n\tSeciminizi yapiniz.");
    scanf("%d",&secim);

    switch(secim)
    {
    case 1:
        printf("\n\n\tSilinecek sehrin plakasini giriniz.");
        scanf("%d",&plaka);
        plakaSil(plaka);
        break;
    case 2:
        printf("\n\n\tSilinecek sehrin ismini giriniz.");
        scanf("%s",&sehir);
        isimSil(sehir);
        break;
    }
}
void plakaKomsuSil(int plaka,char silinecek[500])
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    int boolean=0;
    char *sehir;

    struct node *iter=ilk;

    while(iter->plaka!=plaka)
    {
        iter=iter->next;
    }
    sehir=iter->sehir;
    struct komsu *once=iter->komsu;
    struct komsu *komsuIter=once->ileri;

    if(strstr(iter->komsu->sehir,silinecek)!=0)
    {
        iter->komsu=iter->komsu->ileri;
        boolean=1;
        fprintf(yazma,"%s isimli sehirden %s isimli komsu silindi.\n",sehir,silinecek);
        iter->komsuSayisi=iter->komsuSayisi-1;
    }
    while(komsuIter!=NULL&&boolean==0)
    {
        if(komsuIter->ileri==NULL&&strstr(komsuIter->sehir,silinecek)!=0)
        {
            for(int i=0; i<10; i++)
            {
                komsuIter->sehir[i]="";
            }
            boolean=1;
            iter->komsuSayisi-=1;
            fprintf(yazma,"%s isimli sehirden %s isimli komsu silindi.\n",sehir,silinecek);
            break;
        }
        else if(strstr(komsuIter->sehir,silinecek)!=0)
        {
            once->ileri=komsuIter->ileri;
            boolean=1;
            iter->komsuSayisi-=1;
            fprintf(yazma,"%s isimli sehirden %s isimli komsu silindi.\n",sehir,silinecek);
            break;
        }
        once=once->ileri;
        komsuIter=komsuIter->ileri;
    }
    if(boolean==0)
    {
        printf("\n\n\tBu isimde bir komsu yok.");
    }
}
void isimKomsuSil(char sehir[500],char silinecek[500])
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    int boolean=0;
    struct node *iter=ilk;

    while(strcmp(iter->sehir,sehir)!=0)
    {
        iter=iter->next;
    }
    struct komsu *once=iter->komsu;
    struct komsu *komsuIter=once->ileri;
    if(strstr(iter->komsu->sehir,silinecek)!=0)
    {
        iter->komsu=iter->komsu->ileri;
        boolean=1;
        iter->komsuSayisi-=1;
        fprintf(yazma,"%s isimli sehirden %s isimli komsu silindi.\n",sehir,silinecek);
    }
    while(komsuIter!=NULL&&boolean==0)
    {
        if(komsuIter->ileri==NULL&&strstr(komsuIter->sehir,silinecek)!=0)
        {
            for(int i=0; i<10; i++)
            {
                komsuIter->sehir[i]="";
            }
            boolean=1;
            iter->komsuSayisi-=1;
            fprintf(yazma,"%s isimli sehirden %s isimli komsu silindi.\n",sehir,silinecek);
            break;
        }
        else if(strstr(komsuIter->sehir,silinecek)!=0)
        {
            boolean=1;
            once->ileri=komsuIter->ileri;
            iter->komsuSayisi-=1;
            fprintf(yazma,"%s isimli sehirden %s isimli komsu silindi.\n",sehir,silinecek);
        }
        once=once->ileri;
        komsuIter=komsuIter->ileri;
    }
    if(boolean==0)
    {
        printf("\n\n\tBu isimde bir komsu yok.");
    }
}
void menuGoster()
{
    printf("\n\n\t\t\tMENU\n\t\t1-Sehir ekle\n\t\t2-Komsu ekle\n\t\t");
    printf("3-Sehir sil\n\t\t4-Komsu sil\n\t\t");
    printf("5-Sehir bilgisini goruntule\n\t\t");
    printf("0-Cikis");
}
void bilgiGoruntuleSekmesi(int komsuSayisi[100])
{
    printf("\n\n\n\t\t1-Isim ile arama");
    printf("\n\t\t2-Plaka ile arama");
    printf("\n\t\t3-Bolgede bulunan tum sehirler");
    printf("\n\t\t4-Kritere gore listele");
    printf("\n\t\t0-Cikis");

    bilgiGoruntuleSecimYap(komsuSayisi);
}
void bilgiGoruntuleSecimYap(int komsuSayisi[100])
{
    int secim;
    int aranacakPlaka;
    char sehirIsmi[500];
    char bolgeIsmi[500];

    printf("\n\n\tYapacaginiz islem numarasini giriniz.");
    scanf("%d",&secim);
    switch(secim)
    {
    case 1:
        printf("\n\n\t\tGosterilecek sehrin ismini giriniz.");
        scanf("%s",sehirIsmi);
        isimIleGoster(sehirIsmi);
        break;
    case 2:
        printf("\n\n\t\tGosterilecek sehrin plakasini giriniz.");
        scanf("%d",&aranacakPlaka);
        plakaIleGoster(aranacakPlaka);
        break;
    case 3:
        printf("\n\n\t\tHangi bolgedeki sehirlerin gosterilmesini istersiniz ?");
        scanf("%s",bolgeIsmi);
        bolgedekileriGoster(bolgeIsmi);
        break;
    case 4:
        kritereGore();
        break;
    case -1:
        Listele(komsuSayisi);
        break;
    case 0:
        break;
    }
}
void kritereGore()
{
    int secim;
    printf("\n\n\t\t1-Komsu sayisi \'x\' ten buyuk olan sehirler");
    printf("\n\t\t2-Komsu sayisi \'x\' ten kucuk olan sehirler");
    printf("\n\t\t3-Komsu sayisi \'x\' ile \'y\' arasinda olan sehirler");
    printf("\n\n\tSeciminizi belirtiniz.");
    scanf("%d",&secim);

    switch(secim)
    {
    case 1:
        xDenBuyuk();
        break;
    case 2:
        xDenKucuk();
        break;
    case 3:
        xileyArasinda();
        break;
    }
}
void xileyArasinda()
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    struct node *iter=ilk;
    int az;
    int cok;
    int sayac=0;
    printf("\n\n\tIstenilen araliktan kucuk olani giriniz.");
    scanf("%d",&az);
    printf("\n\n\tIstenilen araliktan buyuk olani giriniz.");
    scanf("%d",&cok);
    fprintf(yazma,"\n\n\t\t%d-%d Araliginda Komsuya Sahip Olan Illerin Listesi: \n",az,cok);
    while(iter->next!=ilk)
    {
        struct komsu *komsuIter=iter->komsu;
        while(komsuIter->ileri!=NULL)
        {
            sayac++;
            komsuIter=komsuIter->ileri;
        }
        if(sayac>=az-1&&sayac<=cok-1)
        {
            komsuIter=iter->komsu;
            fprintf(yazma,"%d %s %s -> ",iter->plaka,iter->sehir,iter->bolge);
            printf("%d\t%s\t%s\t",iter->plaka,iter->sehir,iter->bolge);
            if(komsuIter!=NULL)
            {
                while(komsuIter->ileri!=NULL)
                {
                    fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                    printf("%s ",komsuIter->sehir);
                    komsuIter=komsuIter->ileri;
                }
                fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                printf("%s ",komsuIter->sehir);
            }
            fprintf(yazma,"\n");
        }
        sayac=0;
        iter=iter->next;
    }
}
void xDenKucuk()
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    struct node *iter=ilk;
    int sayi;
    int sayac=0;
    printf("\n\n\tIstenilen komsu sayisini giriniz.");
    scanf("%d",&sayi);
    fprintf(yazma,"\n\n\t\t%d\'den Daha Az Komsuya Sahip Olan Illerin Listesi: \n",sayi);
    while(iter->next!=ilk)
    {
        struct komsu *komsuIter=iter->komsu;
        while(komsuIter->ileri!=NULL)
        {
            sayac++;
            komsuIter=komsuIter->ileri;
        }
        if(sayac<=sayi-1)
        {
            komsuIter=iter->komsu;
            fprintf(yazma,"%d %s %s -> ",iter->plaka,iter->sehir,iter->bolge);
            printf("%d\t%s\t%s\t",iter->plaka,iter->sehir,iter->bolge);
            if(komsuIter!=NULL)
            {
                while(komsuIter->ileri!=NULL)
                {
                    fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                    printf("%s ",komsuIter->sehir);
                    komsuIter=komsuIter->ileri;
                }
                fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                printf("%s ",komsuIter->sehir);
            }
            fprintf(yazma,"\n");
        }
        sayac=0;
        iter=iter->next;
    }
}
void xDenBuyuk()
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    struct node *iter=ilk;
    int sayi;
    int sayac=0;
    printf("\n\n\tIstenilen komsu sayisini giriniz.");
    scanf("%d",&sayi);
    fprintf(yazma,"\n\n\t\t%d\'den Daha Cok Komsuya Sahip Olan Illerin Listesi: \n",sayi);
    while(iter->next!=ilk)
    {
        struct komsu *komsuIter=iter->komsu;
        while(komsuIter->ileri!=NULL)
        {
            sayac++;
            komsuIter=komsuIter->ileri;
        }
        if(sayac>=sayi-1)
        {
            komsuIter=iter->komsu;
            fprintf(yazma,"%d %s %s -> ",iter->plaka,iter->sehir,iter->bolge);
            printf("%d\t%s\t%s\t",iter->plaka,iter->sehir,iter->bolge);
            if(komsuIter!=NULL)
            {
                while(komsuIter->ileri!=NULL)
                {
                    fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                    printf("%s ",komsuIter->sehir);
                    komsuIter=komsuIter->ileri;
                }
                fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                printf("%s ",komsuIter->sehir);
            }
            fprintf(yazma,"\n");
        }
        sayac=0;
        iter=iter->next;
    }
}
void bolgedekileriGoster(char bolgeIsmi[500])
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    struct node *iter=ilk;
    fprintf(yazma,"\n\n\t\t%s Bolgesindeki Tum Iller:\n");
    while(iter->next!=ilk)
    {
        if(strcmp(iter->bolge,bolgeIsmi)==0)
        {
            fprintf(yazma,"%d %s %s -> ",iter->plaka,iter->sehir,iter->bolge);
            printf("%d\t%s\t%s\t",iter->plaka,iter->sehir,iter->bolge);
            struct komsu *komsuIter=iter->komsu;
            if(komsuIter!=NULL)
            {
                while(komsuIter->ileri!=NULL)
                {
                    fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                    printf("%s ",komsuIter->sehir);
                    komsuIter=komsuIter->ileri;
                }
                fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                printf("%s ",komsuIter->sehir);
            }
            fprintf(yazma,"\n");
            printf("\n");
        }
        iter=iter->next;
    }
}
void isimIleGoster(char sehirIsmi[500])
{
    FILE *yazma;
    yazma=fopen(yazma,"\n\n\t\tBilgi Goruntuleme Sekmesine Girildi");
    int boolean=0;
    struct node *iter=ilk;
    struct komsu *komsuIter;

    while(iter->next!=ilk)
    {
        if(strcmp(iter->sehir,sehirIsmi)==0)
        {
            komsuIter=iter->komsu;
            boolean=1;
        }
        iter=iter->next;
    }
    if(strcmp(iter->sehir,sehirIsmi)==0)
    {
        boolean=1;
    }

    if(boolean==1)
    {
        while(strcmp(iter->sehir,sehirIsmi)!=0)
        {
            iter=iter->next;
        }
        fprintf(yazma,"%d %s %s -> ",iter->plaka,iter->sehir,iter->bolge);
        printf("%d\t%s\t%s\t",iter->plaka,iter->sehir,iter->bolge);
        if(komsuIter!=NULL)
        {
            while(komsuIter->ileri!=NULL)
            {
                fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                printf("%s ",komsuIter->sehir);
                komsuIter=komsuIter->ileri;
            }
            fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
            printf("%s ",komsuIter->sehir);
        }
        fprintf(yazma,"\n");
    }
    else
    {
        secimGoster();
    }


}
void plakaIleGoster(int plaka)
{
    FILE *yazma;
    yazma=fopen(yazma,"\n\n\t\tBilgi Goruntuleme Sekmesine Girildi");
    int boolean=0;
    struct komsu *komsuIter;

    struct node *iter=ilk;

    while(iter->next!=ilk)
    {
        if(iter->plaka==plaka)
        {
            komsuIter=iter->komsu;
            boolean=1;
        }
        iter=iter->next;
    }
    if(iter->plaka==plaka)
    {
        boolean=1;
    }

    if(boolean==1)
    {
        while(iter->plaka!=plaka)
        {

            iter=iter->next;
        }
        fprintf(yazma,"%d %s %s -> ",iter->plaka,iter->sehir,iter->bolge);
        printf("%d %s %s ",iter->plaka,iter->sehir,iter->bolge);

        if(komsuIter!=NULL)
        {
            while(komsuIter->ileri!=NULL)
            {
                fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
                printf("%d ",aramaYap(komsuIter->sehir));
                komsuIter=komsuIter->ileri;

            }
            fprintf(yazma,"%d ",dosyaAramaYap(komsuIter->sehir));
            printf("%d ",aramaYap(komsuIter->sehir));
        }
        fprintf(yazma,"\n");
    }
    else
    {
        secimGoster();
    }
}
void secimGoster()
{
    int secim;
    printf("\n\tBoyle bir sehir bulunamadi eklemek ister misiniz?");
    printf("\n\n\t\t1-Evet");
    printf("\n\t\t2-Hayir");
    printf("\n\n\tSeciminizi giriniz.");
    scanf("%d",&secim);

    switch(secim)
    {
    case 1:
        eklemeYap();
        break;
    case 2:
        break;
    }
}
int bagliListeOlustur()
{
    int komsuSayisi[100];
    int keke=0;
    FILE *okuma;
    FILE *plakaOkuma;
    char veri;
    int sayac=0;
    int z=0;
    char gereksiz[500];
    int plaka[100];
    char sehir[500];
    char komsular[500][500];
    char bolge[500];
    int tutucu;
    int j=0;
    int i=0;
    int k=0;
    int satirSayisi=0;
    okuma=fopen("sehirler.txt","r");
    plakaOkuma=fopen("sehirler.txt","r");

    for(int m=0; m<100; m++)
    {
        sonKomsu[m]=NULL;
    }
    while(fscanf(plakaOkuma,"%d,%s",&tutucu,&gereksiz)!=EOF)
    {
        plaka[k]=tutucu;
        k++;
    }

    for(veri=getc(okuma); veri!=EOF; veri=getc(okuma))
    {
        if(veri==',')
        {
            sayac++;
            if(sayac>=3)
            {
                z=0;
            }

        }
        if(sayac==1&&veri!=',')
        {
            sehir[j]=veri;
            j++;
        }
        if(sayac==2&&veri!=',')
        {
            bolge[i]=veri;
            i++;
        }
        if(sayac>=3&&veri!=',')
        {
            komsular[sayac-3][z]=veri;
            z++;
        }
        if(veri=='\n')
        {


            bolge[i]='\0';
            sehir[j]='\0';

            i=0;
            j=0;

            SonaEkle(plaka[satirSayisi],sehir,bolge,sayac-3);
            for(int a=0; a<sayac-2; a++)
            {
                //printf("%s\n",komsular[a]);
                KomsuEkle(komsular[a],satirSayisi);
            }

            for(int c=0; sehir[c]!='\0'; c++)
            {
                sehir[c]=NULL;
            }
            for(int c=0; bolge[c]!='\0'; c++)
            {
                bolge[c]=NULL;
            }
            for(int a=0; a<50; a++)
            {
                for(int b=0; b<50; b++)
                {
                    komsular[a][b]=NULL;
                }
            }
            komsuSayisi[satirSayisi]=sayac-2;
            sayac=0;
            satirSayisi++;
        }
    }
    return komsuSayisi;
}
void eklemeYap()
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    int boolean=0;
    int plaka;
    char sehirIsmi[500];
    char bolge[500];

    printf("\n\n\t\tPlaka giriniz.");
    scanf("%d",&plaka);
    printf("\n\t\tSehir ismi giriniz.");
    scanf("%s",sehirIsmi);
    printf("\n\t\tBolge giriniz.");
    scanf("%s",bolge);
    struct node *iter=ilk;
    while(iter->next!=ilk)
    {
        if(strcmp(iter->sehir,sehirIsmi)==0||iter->plaka==plaka)
        {
            boolean=1;
        }
        iter=iter->next;
    }

    if(strcmp(iter->sehir,sehirIsmi)==0||iter->plaka==plaka)
    {
        boolean=1;
    }

    if(boolean==0)
    {
        SonaEkle(plaka,sehirIsmi,bolge,0);
        fprintf(yazma,"%d %s %s   Sehir eklendi.\n",plaka,sehirIsmi,bolge);
        printf("\n\tEkleme basarili");
    }
    else
    {
        fprintf(yazma,"Girilen ozelliklere sahip sehir zaten listede bulundugu icin ekleme yapilamadi.\n");
        printf("\n\n\tBu ozellikte bir sehir zaten var");
    }
    fclose(yazma);
}
void komsuyaEklemeYap()
{
    int secim;
    int aranacakPlaka;
    char sehirIsmi[500];
    char hangiSehir[500];
    struct node *iter=ilk;

    printf("\n\n\tEkleme yapacaginiz sehri aratmak istediginiz kriteri giriniz.\n");
    printf("\n\t\t1-Plakasini girmek istiyorum");
    printf("\n\t\t2-Ismini girmek istiyorum");
    printf("\n\n\tSeciminizi giriniz.");
    scanf("%d",&secim);
    switch(secim)
    {
    case 1:
        printf("\n\n\t\tEkleme yapilacak sehrin plakasini giriniz.");
        scanf("%d",&aranacakPlaka);
        printf("\n\t\tEklenecek sehir ismi giriniz.");
        scanf("%s",sehirIsmi);
        plakaIleEkle(aranacakPlaka,sehirIsmi);
        break;
    case 2:
        printf("\n\n\t\tEkleme yapilacak sehrin ismini giriniz.");
        scanf("%s",&hangiSehir);
        printf("\n\t\tEklenecek sehir ismi giriniz.");
        scanf("%s",sehirIsmi);
        isimIleEkle(hangiSehir,sehirIsmi);
        break;
    }
}
void isimIleEkle(char hangiSehir[500],char sehirIsmi[500])
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    int boolean=0;
    int sayi=0;
    char ilkUc[10];
    for(int i=0; i<4; i++)
    {
        ilkUc[i]=sehirIsmi[i];
    }

    struct komsu *yeni = (struct komsu*) malloc(sizeof(struct komsu));
    struct node *iter=ilk;

    while(strcmp(iter->sehir,hangiSehir)!=0)
    {
        sayi++;
        iter=iter->next;
    }

    struct komsu *komsuIter=iter->komsu;
    struct komsu *ayniKomsuAramaIteri=iter->komsu;

    if(boolean==0)
    {
        for(int i=0; sehirIsmi[i]!='\0'; i++)
        {
            yeni->sehir[i]=sehirIsmi[i];
        }
        if(komsuIter==NULL)
        {
            sonKomsu[sayi]=yeni;
            iter->komsu=yeni;
            sonKomsu[sayi]->ileri=NULL;
        }
        else
        {
            sonKomsu[sayi]->ileri=yeni;
            sonKomsu[sayi]=yeni;
            sonKomsu[sayi]->ileri=NULL;
        }
        iter->komsuSayisi+=1;
        fprintf(yazma,"%s isimli sehire %s isimli komsu eklendi.\n",hangiSehir,sehirIsmi);
        printf("\n\n\tEkleme basarili.");
    }
    else
    {
        printf(yazma,"%s isimli sehrin %s isimli komsusu zaten var.\n",hangiSehir,sehirIsmi);
        printf("\n\n\tBu isimde komsu zaten var");
    }
    fclose(yazma);
}

void plakaIleEkle(int aranacakPlaka,char sehirIsmi[500])
{
    FILE *yazma;
    yazma=fopen("cikti.txt","a");
    int boolean=0;
    int sayi=0;
    char ilkUc[10];
    char *eklenen;
    for(int i=0; i<4; i++)
    {
        ilkUc[i]=sehirIsmi[i];
    }
    struct komsu *yeni = (struct komsu*) malloc(sizeof(struct komsu));
    struct node *iter=ilk;

    while(iter->plaka!=aranacakPlaka)
    {
        sayi++;
        iter=iter->next;
    }
    eklenen=iter->sehir;

    struct komsu *komsuIter=iter->komsu;
    struct komsu *ayniKomsuAramaIteri=iter->komsu;
    if(ayniKomsuAramaIteri!=NULL)
    {
        while(ayniKomsuAramaIteri->ileri!=NULL)
        {
            if(strstr(ayniKomsuAramaIteri->sehir,ilkUc)!=0)
            {
                printf("@@@@@@@@@@@@@@@@@@");
                boolean=1;
            }
            ayniKomsuAramaIteri=ayniKomsuAramaIteri->ileri;
        }
        if(strstr(ayniKomsuAramaIteri->sehir,ilkUc)!=0)
        {
            boolean=1;
        }
        if(boolean==0)
        {
            for(int i=0; sehirIsmi[i]!='\0'; i++)
            {
                yeni->sehir[i]=sehirIsmi[i];
            }
            if(komsuIter==NULL)
            {
                sonKomsu[sayi]=yeni;
                iter->komsu=yeni;
                sonKomsu[sayi]->ileri=NULL;
            }
            else
            {
                sonKomsu[sayi]->ileri=yeni;
                sonKomsu[sayi]=yeni;
                sonKomsu[sayi]->ileri=NULL;
            }
            iter->komsuSayisi+=1;
            fprintf(yazma,"%s isimli sehire %s isimli komsu eklendi\n",eklenen,sehirIsmi);
            printf("\n\n\tEkleme basarili.");
        }
        else
        {
            printf(yazma,"%s isimli sehrin %s isimli komsusu zaten var\n",eklenen,sehirIsmi);
            printf("\n\n\tBu isimde komsu zaten var");
        }
    }
    else
    {
        if(boolean==0)
        {
            for(int i=0; sehirIsmi[i]!='\0'; i++)
            {
                yeni->sehir[i]=sehirIsmi[i];
            }
            if(komsuIter==NULL)
            {
                sonKomsu[sayi]=yeni;
                iter->komsu=yeni;
                sonKomsu[sayi]->ileri=NULL;
            }
            else
            {
                sonKomsu[sayi]->ileri=yeni;
                sonKomsu[sayi]=yeni;
                sonKomsu[sayi]->ileri=NULL;
            }
            fprintf(yazma,"%s isimli sehire %s isimli komsu eklendi\n",eklenen,sehirIsmi);
            printf("\n\n\tEkleme basarili.");
        }
        else
        {
            printf(yazma,"%s isimli sehrin %s isimli komsusu zaten var\n",eklenen,sehirIsmi);
            printf("\n\n\tBu isimde komsu zaten var");
        }
    }



}
void aramaYap(char komsu[500])
{
    struct node *iter=ilk;

    int eklenecekPlaka=0;
    char ilkUc[5];


    for(int i=0; i<4; i++)
    {
        ilkUc[i]=komsu[i];
    }

    while(iter->next!=ilk)
    {
        if(strstr(iter->sehir,ilkUc)!=0)
        {
            eklenecekPlaka=iter->plaka;
        }
        iter=iter->next;
    }
    if(strstr(iter->sehir,ilkUc)!=0)
    {
        eklenecekPlaka=iter->plaka;
    }
    if(eklenecekPlaka!=0)
    {
        printf("%d ",eklenecekPlaka);
    }

}
int dosyaAramaYap(char komsu[500])
{
    struct node *iter=ilk;

    int eklenecekPlaka=0;
    char ilkUc[5];

    for(int i=0; i<4; i++)
    {
        ilkUc[i]=komsu[i];
    }

    while(iter->next!=ilk)
    {
        if(strstr(iter->sehir,ilkUc)!=0)
        {
            eklenecekPlaka=iter->plaka;
        }
        iter=iter->next;
    }
    if(strstr(iter->sehir,ilkUc)!=0)
    {
        eklenecekPlaka=iter->plaka;
    }
    return eklenecekPlaka;
}
void bagliListeSirala()
{
    struct node *iter=ilk;
    while(iter->next!=ilk)
    {
        if(iter->plaka<iter->next->plaka)
        {
            struct node *temp=iter;
            iter=iter->next;
            iter->next=temp;
        }
    }
}
